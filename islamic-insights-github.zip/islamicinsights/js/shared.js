// shared.js — Common header/footer injector

const SITE = {
  name: 'Islamic Insights',
  tagline: 'Quran & AhlulBayt',
  ga: 'G-VZJ1ETL0JQ',
  fb: 'https://www.facebook.com/profile.php?id=61589673759462',
  yt: 'https://www.youtube.com/@ismlamicinsights110-u6f',
  easypaisa: '03337546622',
  jazzcash: '03337546622',
  paypal: 'https://www.paypal.com/donate/?hosted_button_id=IslamicInsights',
};

// NAV links
const NAV_LINKS = [
  { href: 'index.html', label: 'Home' },
  { href: 'quran.html', label: '📖 Quran' },
  { href: 'namaz.html', label: '🕌 Namaz' },
  { href: 'qibla.html', label: '🧭 Qibla' },
  { href: 'duas.html', label: '🤲 Duaen' },
  { href: 'nahj.html', label: 'Nahj al-Balagha' },
  { href: 'ziyarat.html', label: 'Ziyarat' },
  { href: 'hadith.html', label: 'Ahadith' },
  { href: 'history.html', label: 'History' },
  { href: 'donate.html', label: '💚 Donate' },
];

function getLogo() {
  return `<a href="index.html" class="logo">
    <div class="logo-emblem"><svg viewBox="0 0 52 52"><rect width="52" height="52" rx="13" fill="#0a4a2a"/><text x="26" y="36" font-family="Scheherazade New,serif" font-size="28" fill="#c8941c" text-anchor="middle">☪</text><rect x="6" y="6" width="40" height="40" rx="9" fill="none" stroke="rgba(200,148,28,0.3)" stroke-width="1"/></svg></div>
    <div class="logo-text"><h1>Islamic Insights</h1><p>Quran &amp; AhlulBayt</p></div>
  </a>`;
}

function getSocials(cls='') {
  return `<a href="${SITE.fb}" target="_blank" rel="noopener" aria-label="Facebook"><svg viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg></a>
  <a href="${SITE.yt}" target="_blank" rel="noopener" aria-label="YouTube"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M22.54 6.42a2.78 2.78 0 00-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 00-1.95 1.96A29 29 0 001 12a29 29 0 00.46 5.58A2.78 2.78 0 003.41 19.54C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 001.95-1.96A29 29 0 0023 12a29 29 0 00-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02" fill="white"/></svg></a>`;
}

function buildHeader(activePage) {
  const navHTML = NAV_LINKS.map(l => 
    `<a href="${l.href}" class="${l.href === activePage ? 'active' : ''}">${l.label}</a>`
  ).join('');
  const mobileNavHTML = NAV_LINKS.map(l => 
    `<a href="${l.href}">${l.label}</a>`
  ).join('');

  return `
<!-- MOBILE NAV -->
<div class="mobile-nav" id="mobileNav">
  <button class="mobile-nav-close" onclick="document.getElementById('mobileNav').classList.remove('open')">✕</button>
  ${mobileNavHTML}
</div>
<!-- TOPBAR -->
<div class="topbar">
  <div class="topbar-inner">
    <div class="topbar-bismillah">بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيمِ</div>
    <div class="topbar-social">
      <span class="lbl">Follow</span>
      ${getSocials('topbar')}
    </div>
  </div>
</div>
<!-- HEADER -->
<header>
  <div class="header-inner">
    ${getLogo()}
    <nav>${navHTML}</nav>
    <button class="hamburger" onclick="document.getElementById('mobileNav').classList.add('open')" aria-label="Menu">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>`;
}

function buildFooter() {
  const year = new Date().getFullYear();
  return `
<footer>
  <div class="footer-top">
    <div class="footer-brand">
      <div class="fl">☪ Islamic Insights</div>
      <p>Quran, AhlulBayt, Ahadith, Nahj al-Balagha, Ziyarat, Duas, Islamic History aur bahut kuch — sab ek jagah.</p>
      <div class="footer-socials">${getSocials('footer')}</div>
      <div class="footer-donate">
        <p>📱 Donate via EasyPaisa / JazzCash:</p>
        <span class="phone">${SITE.easypaisa}</span>
        <a href="${SITE.paypal}" target="_blank" rel="noopener" style="color:var(--gold-light);font-size:13px;text-decoration:none;">💛 Donate via PayPal →</a>
      </div>
    </div>
    <div class="footer-col">
      <h4>Quran & Dua</h4>
      <a href="quran.html">📖 Quran 30 Para</a>
      <a href="duas.html">🤲 Dua Kumayl</a>
      <a href="duas.html">🤲 Dua Tawassul</a>
      <a href="ziyarat.html">Ziyarat Ashura</a>
      <a href="nahj.html">Nahj al-Balagha</a>
    </div>
    <div class="footer-col">
      <h4>Islamic Tools</h4>
      <a href="namaz.html">🕌 Namaz Timings</a>
      <a href="qibla.html">🧭 Qibla Direction</a>
      <a href="hadith.html">Ahadith</a>
      <a href="history.html">Islamic History</a>
    </div>
    <div class="footer-col">
      <h4>About Us</h4>
      <a href="about.html">About Islamic Insights</a>
      <a href="donate.html">Support Us</a>
      <a href="${SITE.fb}" target="_blank" rel="noopener">Facebook Page</a>
      <a href="${SITE.yt}" target="_blank" rel="noopener">YouTube Channel</a>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© ${year} Islamic Insights. All rights reserved.</span>
    <div class="footer-links">
      <a href="about.html">About</a>
      <a href="donate.html">Donate</a>
      <a href="${SITE.fb}" target="_blank" rel="noopener">Facebook</a>
    </div>
  </div>
</footer>`;
}
