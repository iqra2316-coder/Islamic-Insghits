// js/quran.js — Quran 30 Para Data + Verse Loader

const QURAN_PARAS = [
  { num: 1,  ar: "الم",           en: "Alif Lam Meem",         surah: "Al-Fatiha – Al-Baqarah 141", start: "1:1" },
  { num: 2,  ar: "سَيَقُولُ",     en: "Sayaqool",               surah: "Al-Baqarah 142–252",         start: "2:142" },
  { num: 3,  ar: "تِلْكَ الرُّسُلُ", en: "Tilka'r Rusul",       surah: "Al-Baqarah 253 – Aal Imran 91", start: "2:253" },
  { num: 4,  ar: "لَن تَنَالُوا", en: "Lan Tanaloo",            surah: "Aal Imran 92 – An-Nisa 23",  start: "3:92" },
  { num: 5,  ar: "وَالْمُحْصَنَاتُ", en: "Wal Mohsanat",        surah: "An-Nisa 24–147",             start: "4:24" },
  { num: 6,  ar: "لَا يُحِبُّ اللَّهُ", en: "La Yuhibbu Allah", surah: "An-Nisa 148 – Al-Maidah 81", start: "4:148" },
  { num: 7,  ar: "وَإِذَا سَمِعُوا", en: "Wa Iza Samioo",       surah: "Al-Maidah 82 – Al-An'am 110", start: "5:82" },
  { num: 8,  ar: "وَلَوْ أَنَّنَا", en: "Wa Lau Annana",        surah: "Al-An'am 111 – Al-A'raf 87", start: "6:111" },
  { num: 9,  ar: "قَالَ الْمَلَأُ", en: "Qalal Malao",          surah: "Al-A'raf 88 – Al-Anfal 40",  start: "7:88" },
  { num: 10, ar: "وَاعْلَمُوا",    en: "Wa A'lamu",              surah: "Al-Anfal 41 – At-Tawbah 92", start: "8:41" },
  { num: 11, ar: "يَعْتَذِرُونَ",  en: "Ya'tazeroon",            surah: "At-Tawbah 93 – Hud 5",       start: "9:93" },
  { num: 12, ar: "وَمَا مِن دَابَّةٍ", en: "Wa Mamin Dabbah",   surah: "Hud 6 – Yusuf 52",           start: "11:6" },
  { num: 13, ar: "وَمَا أُبَرِّئُ", en: "Wa Ma Ubarrio",         surah: "Yusuf 53 – Ibrahim 52",      start: "12:53" },
  { num: 14, ar: "رُبَمَا",        en: "Rubama",                  surah: "Al-Hijr – An-Nahl 128",      start: "15:1" },
  { num: 15, ar: "سُبْحَانَ الَّذِي", en: "Subhanallazi",        surah: "Al-Isra – Al-Kahf 74",       start: "17:1" },
  { num: 16, ar: "قَالَ أَلَمْ",    en: "Qala Alam",              surah: "Al-Kahf 75 – Ta-Ha 135",     start: "18:75" },
  { num: 17, ar: "اقْتَرَبَ",      en: "Iqtaraba",               surah: "Al-Anbiya – Al-Hajj 78",     start: "21:1" },
  { num: 18, ar: "قَدْ أَفْلَحَ",  en: "Qad Aflaha",              surah: "Al-Muminoon – Al-Furqan 20", start: "23:1" },
  { num: 19, ar: "وَقَالَ الَّذِينَ", en: "Wa Qalal Lazeena",   surah: "Al-Furqan 21 – An-Naml 55",  start: "25:21" },
  { num: 20, ar: "أَمَّن خَلَقَ",  en: "Aman Khalaq",             surah: "An-Naml 56 – Al-Ankabut 45", start: "27:56" },
  { num: 21, ar: "اتْلُ مَا أُوحِيَ", en: "Otlu Ma Oohiya",     surah: "Al-Ankabut 46 – Al-Ahzab 30", start: "29:46" },
  { num: 22, ar: "وَمَن يَقْنُتْ",  en: "Wa Manyaqnut",           surah: "Al-Ahzab 31 – Ya-Seen 27",  start: "33:31" },
  { num: 23, ar: "وَمَا لِيَ",      en: "Wa Mali",                 surah: "Ya-Seen 28 – Az-Zumar 31",  start: "36:28" },
  { num: 24, ar: "فَمَنْ أَظْلَمُ", en: "Faman Azlam",            surah: "Az-Zumar 32 – Fussilat 46", start: "39:32" },
  { num: 25, ar: "إِلَيْهِ يُرَدُّ", en: "Elahe Yuraddo",         surah: "Fussilat 47 – Al-Jathiya 37", start: "41:47" },
  { num: 26, ar: "حم",             en: "Ha Meem",                  surah: "Al-Ahqaf – Az-Zariyat 30",  start: "46:1" },
  { num: 27, ar: "قَالَ فَمَا خَطْبُكُمْ", en: "Qala Fama Khatbukum", surah: "Az-Zariyat 31 – Al-Hadid 29", start: "51:31" },
  { num: 28, ar: "قَدْ سَمِعَ اللَّهُ", en: "Qad Sameallah",     surah: "Al-Mujadila – At-Tahrim",    start: "58:1" },
  { num: 29, ar: "تَبَارَكَ الَّذِي", en: "Tabarakallazi",        surah: "Al-Mulk – Al-Mursalat",      start: "67:1" },
  { num: 30, ar: "عَمَّ",           en: "Amma",                    surah: "An-Naba – An-Nas",           start: "78:1" }
];

// Public domain Quran API (everyayah.com for audio, alquran.cloud for text)
const QURAN_API_BASE = 'https://api.alquran.cloud/v1';
const AUDIO_BASE = 'https://cdn.islamic.network/quran/audio/128/ar.alafasy'; // Mishary Rashid Alafasy

// Para to Surah mapping for API calls
const PARA_SURAH_MAP = {
  1:  { surahs: [1, 2], startAyah: 1 },
  2:  { surahs: [2], startAyah: 142 },
  3:  { surahs: [2, 3], startAyah: 253 },
  4:  { surahs: [3, 4], startAyah: 92 },
  5:  { surahs: [4], startAyah: 24 },
  6:  { surahs: [4, 5], startAyah: 148 },
  7:  { surahs: [5, 6], startAyah: 82 },
  8:  { surahs: [6, 7], startAyah: 111 },
  9:  { surahs: [7, 8], startAyah: 88 },
  10: { surahs: [8, 9], startAyah: 41 },
  30: { surahs: [78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114], startAyah: 1 }
};

// Sample verses for offline fallback (Para 1 - Al-Fatiha)
const SAMPLE_VERSES = {
  1: [
    {
      number: 1,
      arabic: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
      urdu: "اللہ کے نام سے جو بہت مہربان، نہایت رحم والا ہے",
      english: "In the name of Allah, the Most Gracious, the Most Merciful"
    },
    {
      number: 2,
      arabic: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
      urdu: "تمام تعریفیں اللہ کے لیے ہیں جو تمام جہانوں کا پالنہار ہے",
      english: "All praise is due to Allah, Lord of all the worlds"
    },
    {
      number: 3,
      arabic: "الرَّحْمَٰنِ الرَّحِيمِ",
      urdu: "بہت مہربان، نہایت رحم والا",
      english: "The Most Gracious, the Most Merciful"
    },
    {
      number: 4,
      arabic: "مَالِكِ يَوْمِ الدِّينِ",
      urdu: "روز جزا کا مالک",
      english: "Master of the Day of Judgment"
    },
    {
      number: 5,
      arabic: "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ",
      urdu: "ہم تیری ہی عبادت کرتے ہیں اور تجھ سے ہی مدد مانگتے ہیں",
      english: "You alone we worship, and You alone we ask for help"
    },
    {
      number: 6,
      arabic: "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ",
      urdu: "ہمیں سیدھی راہ دکھا",
      english: "Guide us to the straight path"
    },
    {
      number: 7,
      arabic: "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ",
      urdu: "ان لوگوں کی راہ جن پر تو نے انعام کیا، نہ کہ ان لوگوں کی جن پر غضب ہوا اور نہ گمراہوں کی",
      english: "The path of those You have blessed, not those who have incurred anger, nor those who have gone astray"
    }
  ]
};

// Fetch Para content from API
async function fetchParaVerses(paraNum) {
  try {
    // Using alquran.cloud API - Juz endpoint
    const [arabicRes, urduRes, englishRes] = await Promise.allSettled([
      fetch(`${QURAN_API_BASE}/juz/${paraNum}/quran-uthmani`),
      fetch(`${QURAN_API_BASE}/juz/${paraNum}/ur.jalandhry`),
      fetch(`${QURAN_API_BASE}/juz/${paraNum}/en.sahih`)
    ]);

    let verses = [];

    if (arabicRes.status === 'fulfilled' && arabicRes.value.ok) {
      const arabicData = await arabicRes.value.json();
      const urduData = urduRes.status === 'fulfilled' ? await urduRes.value.json() : null;
      const engData = englishRes.status === 'fulfilled' ? await englishRes.value.json() : null;

      const arabicAyahs = arabicData.data?.ayahs || [];
      const urduAyahs = urduData?.data?.ayahs || [];
      const engAyahs = engData?.data?.ayahs || [];

      verses = arabicAyahs.map((ayah, i) => ({
        number: ayah.numberInSurah,
        surah: ayah.surah?.englishName || '',
        surahAr: ayah.surah?.name || '',
        ayahNum: ayah.number,
        arabic: ayah.text,
        urdu: urduAyahs[i]?.text || '',
        english: engAyahs[i]?.text || ''
      }));
    } else {
      // Fallback to sample
      verses = SAMPLE_VERSES[paraNum] || SAMPLE_VERSES[1];
    }

    return verses;
  } catch (e) {
    console.log('Using offline Quran data');
    return SAMPLE_VERSES[paraNum] || SAMPLE_VERSES[1];
  }
}

// Get audio URL for a verse
function getVerseAudioUrl(ayahNumber, reciter = 'ar.alafasy') {
  const reciterMap = {
    'ar.alafasy': 'ar.alafasy',
    'ar.abdurrahmaansudais': 'ar.abdurrahmaansudais',
    'ar.hudhaify': 'ar.hudhaify',
    'ar.minshawi': 'ar.minshawi'
  };
  const r = reciterMap[reciter] || 'ar.alafasy';
  return `https://cdn.islamic.network/quran/audio/128/${r}/${ayahNumber}.mp3`;
}

// Get para audio URL (full para streaming)
function getParaAudioUrl(paraNum, reciter = 'ar.alafasy') {
  // Using EveryAyah.com for para audio
  return `https://download.quranicaudio.com/quran/mishary_alafasy/${String(paraNum).padStart(3,'0')}.mp3`;
}

window.QuranData = { QURAN_PARAS, fetchParaVerses, getVerseAudioUrl, getParaAudioUrl, SAMPLE_VERSES };
