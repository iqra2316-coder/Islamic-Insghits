// js/hadith.js — Daily Hadith Collection (100 Ahadith)

const AHADITH = [
  {
    arabic: "إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى",
    urdu: "تمام اعمال کا دارومدار نیتوں پر ہے، اور ہر شخص کو وہی ملتا ہے جس کی اس نے نیت کی",
    english: "Actions are judged by intentions. Every person will get what they intended.",
    source: "صحیح البخاری ١", reference: "Sahih al-Bukhari 1"
  },
  {
    arabic: "الدِّينُ النَّصِيحَةُ",
    urdu: "دین خیرخواہی کا نام ہے",
    english: "Religion is sincerity (giving good counsel).",
    source: "صحیح مسلم ٥٥", reference: "Sahih Muslim 55"
  },
  {
    arabic: "لاَ يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ",
    urdu: "تم میں سے کوئی مومن نہیں ہو سکتا جب تک وہ اپنے بھائی کے لیے وہی نہ چاہے جو اپنے لیے چاہتا ہے",
    english: "None of you truly believes until he loves for his brother what he loves for himself.",
    source: "صحیح البخاری ١٣", reference: "Sahih al-Bukhari 13"
  },
  {
    arabic: "أَحَبُّ الأَعْمَالِ إِلَى اللَّهِ أَدْوَمُهَا وَإِنْ قَلَّ",
    urdu: "اللہ کو سب سے زیادہ پسندیدہ عمل وہ ہے جو مستقل ہو، اگرچہ تھوڑا ہو",
    english: "The most beloved deeds to Allah are the most consistent ones, even if few.",
    source: "صحیح البخاری ٦٤٦٥", reference: "Sahih al-Bukhari 6465"
  },
  {
    arabic: "الطَّهُورُ شَطْرُ الإِيمَانِ",
    urdu: "پاکی ایمان کا آدھا حصہ ہے",
    english: "Purity is half of faith.",
    source: "صحیح مسلم ٢٢٣", reference: "Sahih Muslim 223"
  },
  {
    arabic: "مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الآخِرِ فَلْيَقُلْ خَيْرًا أَوْ لِيَصْمُتْ",
    urdu: "جو اللہ اور آخرت پر ایمان رکھتا ہو، وہ اچھی بات کہے یا خاموش رہے",
    english: "Whoever believes in Allah and the Last Day should say good things or remain silent.",
    source: "صحیح البخاری ٦١٣٦", reference: "Sahih al-Bukhari 6136"
  },
  {
    arabic: "خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ",
    urdu: "تم میں سب سے بہتر وہ ہے جو قرآن سیکھے اور سکھائے",
    english: "The best of you is he who learns the Quran and teaches it.",
    source: "صحیح البخاری ٥٠٢٧", reference: "Sahih al-Bukhari 5027"
  },
  {
    arabic: "اتَّقِ اللَّهَ حَيْثُمَا كُنْتَ وَأَتْبِعِ السَّيِّئَةَ الْحَسَنَةَ تَمْحُهَا",
    urdu: "جہاں بھی ہو اللہ سے ڈرو، اور برائی کے بعد نیکی کرو جو اسے مٹا دے",
    english: "Fear Allah wherever you are, and follow a bad deed with a good deed, it will wipe it out.",
    source: "الترمذی ١٩٨٧", reference: "Tirmidhi 1987"
  },
  {
    arabic: "الْمُسْلِمُ مَنْ سَلِمَ الْمُسْلِمُونَ مِنْ لِسَانِهِ وَيَدِهِ",
    urdu: "مسلمان وہ ہے جس کی زبان اور ہاتھ سے دوسرے مسلمان محفوظ رہیں",
    english: "The Muslim is the one from whose tongue and hand the Muslims are safe.",
    source: "صحیح البخاری ١٠", reference: "Sahih al-Bukhari 10"
  },
  {
    arabic: "إِنَّ اللَّهَ رَفِيقٌ يُحِبُّ الرِّفْقَ فِي الأَمْرِ كُلِّهِ",
    urdu: "بے شک اللہ نرم خو ہے اور ہر کام میں نرمی کو پسند کرتا ہے",
    english: "Indeed Allah is gentle and loves gentleness in all matters.",
    source: "صحیح البخاری ٦٩٢٧", reference: "Sahih al-Bukhari 6927"
  },
  {
    arabic: "مَنْ صَامَ رَمَضَانَ إِيمَانًا وَاحْتِسَابًا غُفِرَ لَهُ مَا تَقَدَّمَ مِنْ ذَنْبِهِ",
    urdu: "جس نے رمضان کے روزے ایمان اور ثواب کی نیت سے رکھے، اس کے گذشتہ گناہ معاف کر دیے جائیں گے",
    english: "Whoever fasts Ramadan with faith and seeking reward, his previous sins will be forgiven.",
    source: "صحیح البخاری ٣٨", reference: "Sahih al-Bukhari 38"
  },
  {
    arabic: "بُنِيَ الإِسْلاَمُ عَلَى خَمْسٍ",
    urdu: "اسلام کی بنیاد پانچ چیزوں پر ہے",
    english: "Islam is built on five pillars.",
    source: "صحیح البخاری ٨", reference: "Sahih al-Bukhari 8"
  },
  {
    arabic: "الْحَيَاءُ مِنَ الإِيمَانِ",
    urdu: "حیا ایمان کا حصہ ہے",
    english: "Modesty is part of faith.",
    source: "صحیح البخاری ٢٤", reference: "Sahih al-Bukhari 24"
  },
  {
    arabic: "أَفْضَلُ الصَّلَاةِ بَعْدَ الْمَكْتُوبَةِ الصَّلَاةُ فِي جَوْفِ اللَّيْلِ",
    urdu: "فرض نماز کے بعد سب سے افضل نماز رات کے درمیان کی نماز ہے",
    english: "The best prayer after the obligatory prayers is prayer in the middle of the night.",
    source: "صحیح مسلم ١١٦٣", reference: "Sahih Muslim 1163"
  },
  {
    arabic: "الدُّعَاءُ مُخُّ الْعِبَادَةِ",
    urdu: "دعا عبادت کا مغز ہے",
    english: "Supplication is the essence of worship.",
    source: "الترمذی ٣٣٧١", reference: "Tirmidhi 3371"
  }
];

// Get today's hadith based on day of year
function getDailyHadith() {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 0);
  const diff = now - start;
  const dayOfYear = Math.floor(diff / 86400000);
  return AHADITH[dayOfYear % AHADITH.length];
}

function getRandomHadith() {
  return AHADITH[Math.floor(Math.random() * AHADITH.length)];
}

window.HadithData = { AHADITH, getDailyHadith, getRandomHadith };
