// js/app.js — Islamic Insights PWA Main Controller

'use strict';

// ── PWA Install ──
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  deferredPrompt = e;
  document.querySelector('.btn-install')?.classList.add('visible');
});

document.querySelector('.btn-install')?.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  if (outcome === 'accepted') showToast('✅ App installed!');
  deferredPrompt = null;
});

// ── Service Worker ──
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(reg => console.log('SW registered:', reg.scope))
      .catch(err => console.log('SW error:', err));
  });
}

// ── Offline Detection ──
const offlineBanner = document.getElementById('offline-banner');
window.addEventListener('offline', () => offlineBanner?.classList.add('show'));
window.addEventListener('online', () => {
  offlineBanner?.classList.remove('show');
  showToast('🌐 Back online');
});

// ── Toast ──
function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3000);
}

// ── Navigation ──
const tabs = document.querySelectorAll('.nav-tab');
const screens = document.querySelectorAll('.screen');

function switchTab(id) {
  tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === id));
  screens.forEach(s => s.classList.toggle('active', s.id === `screen-${id}`));
  localStorage.setItem('lastTab', id);

  // Lazy-init screens
  if (id === 'prayer') initPrayer();
  if (id === 'qibla') initQibla();
  if (id === 'hadith') initHadith();
  if (id === 'donate') initDonate();
}

tabs.forEach(tab => {
  tab.addEventListener('click', () => switchTab(tab.dataset.tab));
});

// ── Loading Screen ──
window.addEventListener('load', () => {
  setTimeout(() => {
    document.getElementById('loading')?.classList.add('hidden');
    const last = localStorage.getItem('lastTab') || 'quran';
    switchTab(last);
  }, 1200);
});

// ═══════════════════════════════════════
//  QURAN MODULE
// ═══════════════════════════════════════
const quranGrid = document.getElementById('para-grid');
const quranReader = document.getElementById('quran-reader');
const quranList = document.getElementById('quran-list');
const paraListView = document.getElementById('para-list-view');

let currentPara = null;
let currentAudio = null;
let currentVerses = [];
let transMode = 'none'; // 'none' | 'urdu' | 'english'
let currentReciter = 'ar.alafasy';
let isPlaying = false;
let currentAyahIdx = 0;

// Build para grid
if (quranGrid && window.QuranData) {
  QuranData.QURAN_PARAS.forEach(para => {
    const card = document.createElement('div');
    card.className = 'para-card';
    card.innerHTML = `
      <span class="para-number">${para.ar}</span>
      <span class="para-name">${para.en}</span>
      <span class="para-info">Para ${para.num}</span>
    `;
    card.addEventListener('click', () => openPara(para));
    quranGrid.appendChild(card);
  });
}

// Search filter
document.getElementById('quran-search')?.addEventListener('input', e => {
  const q = e.target.value.toLowerCase();
  document.querySelectorAll('.para-card').forEach((card, i) => {
    const para = QuranData.QURAN_PARAS[i];
    const match = para.en.toLowerCase().includes(q) || String(para.num).includes(q);
    card.style.display = match ? '' : 'none';
  });
});

async function openPara(para) {
  currentPara = para;
  paraListView.style.display = 'none';
  quranReader.classList.add('active');

  document.getElementById('reader-para-title').textContent = `Para ${para.num} — ${para.en}`;
  document.getElementById('reader-para-ar').textContent = para.ar;
  quranList.innerHTML = `<div style="text-align:center;padding:40px;color:var(--text-muted)">📖 جاری ہے...</div>`;

  const verses = await QuranData.fetchParaVerses(para.num);
  currentVerses = verses;
  renderVerses(verses);
}

function renderVerses(verses) {
  quranList.innerHTML = '';
  verses.forEach((v, i) => {
    const div = document.createElement('div');
    div.className = 'verse-card';
    div.id = `verse-${i}`;
    div.innerHTML = `
      <div class="verse-number">${v.number || i + 1}</div>
      <div class="verse-arabic">${v.arabic}</div>
      ${v.urdu ? `<div class="verse-urdu${transMode === 'urdu' ? ' show' : ''}">${v.urdu}</div>` : ''}
      ${v.english ? `<div class="verse-english${transMode === 'english' ? ' show' : ''}">${v.english}</div>` : ''}
      <div class="verse-actions">
        <button class="verse-btn" onclick="playVerse(${i})">▶ Listen</button>
        <button class="verse-btn" onclick="copyVerse(${i})">📋 Copy</button>
        <button class="verse-btn" onclick="shareVerse(${i})">📤 Share</button>
      </div>
    `;
    quranList.appendChild(div);
  });
}

function closePara() {
  stopAudio();
  quranReader.classList.remove('active');
  paraListView.style.display = '';
}

function setTranslation(mode) {
  transMode = mode;
  document.querySelectorAll('.trans-btn').forEach(b => b.classList.toggle('active', b.dataset.trans === mode));
  document.querySelectorAll('.verse-urdu').forEach(el => el.classList.toggle('show', mode === 'urdu'));
  document.querySelectorAll('.verse-english').forEach(el => el.classList.toggle('show', mode === 'english'));
}

// Audio playback
function playPara() {
  if (!currentPara) return;
  const url = QuranData.getParaAudioUrl(currentPara.num, currentReciter);
  playAudioUrl(url);
}

function playVerse(idx) {
  if (!currentVerses[idx]) return;
  const ayah = currentVerses[idx];
  const url = QuranData.getVerseAudioUrl(ayah.ayahNum || idx + 1, currentReciter);
  playAudioUrl(url);
  currentAyahIdx = idx;
  document.getElementById(`verse-${idx}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function playAudioUrl(url) {
  stopAudio();
  currentAudio = new Audio(url);
  currentAudio.addEventListener('timeupdate', updateProgress);
  currentAudio.addEventListener('ended', onAudioEnd);
  currentAudio.addEventListener('error', () => showToast('❌ Audio not available offline'));
  currentAudio.play().catch(() => showToast('❌ Cannot play audio'));
  isPlaying = true;
  updatePlayBtn(true);
}

function stopAudio() {
  if (currentAudio) {
    currentAudio.pause();
    currentAudio.src = '';
    currentAudio = null;
  }
  isPlaying = false;
  updatePlayBtn(false);
}

function toggleAudio() {
  if (!currentAudio || currentAudio.ended) {
    playPara();
    return;
  }
  if (isPlaying) {
    currentAudio.pause();
    isPlaying = false;
    updatePlayBtn(false);
  } else {
    currentAudio.play();
    isPlaying = true;
    updatePlayBtn(true);
  }
}

function updatePlayBtn(playing) {
  const btn = document.getElementById('play-btn');
  if (btn) btn.textContent = playing ? '⏸' : '▶';
}

function updateProgress() {
  if (!currentAudio) return;
  const pct = (currentAudio.currentTime / currentAudio.duration * 100) || 0;
  const bar = document.getElementById('audio-progress');
  if (bar) {
    bar.value = pct;
    bar.style.setProperty('--progress', pct + '%');
  }
  const curr = document.getElementById('time-current');
  const total = document.getElementById('time-total');
  if (curr) curr.textContent = formatTime(currentAudio.currentTime);
  if (total) total.textContent = formatTime(currentAudio.duration || 0);
}

function onAudioEnd() {
  isPlaying = false;
  updatePlayBtn(false);
}

function seekAudio(e) {
  if (currentAudio && currentAudio.duration) {
    currentAudio.currentTime = (e.target.value / 100) * currentAudio.duration;
  }
}

function formatTime(s) {
  if (!s || isNaN(s)) return '0:00';
  const m = Math.floor(s / 60), sec = Math.floor(s % 60);
  return `${m}:${String(sec).padStart(2, '0')}`;
}

function copyVerse(idx) {
  const v = currentVerses[idx];
  if (!v) return;
  const text = `${v.arabic}\n${v.urdu || ''}\n${v.english || ''}\n— القرآن الكريم`;
  navigator.clipboard?.writeText(text).then(() => showToast('📋 Copied!'));
}

function shareVerse(idx) {
  const v = currentVerses[idx];
  if (!v) return;
  const text = `${v.arabic}\n\n${v.english || ''}\n\n— الذكر الحكيم | Islamic Insights`;
  if (navigator.share) {
    navigator.share({ title: 'Quran Verse', text }).catch(() => {});
  } else {
    navigator.clipboard?.writeText(text).then(() => showToast('📋 Copied for sharing!'));
  }
}

window.openPara = openPara;
window.closePara = closePara;
window.setTranslation = setTranslation;
window.toggleAudio = toggleAudio;
window.playVerse = playVerse;
window.seekAudio = seekAudio;
window.copyVerse = copyVerse;
window.shareVerse = shareVerse;

// ═══════════════════════════════════════
//  NAHJ AL-BALAGHA MODULE
// ═══════════════════════════════════════
let nahjType = 'sermons';

function initNahj() {
  renderNahj('sermons');
}

function switchNahjTab(type) {
  nahjType = type;
  document.querySelectorAll('.nahj-tab').forEach(t => t.classList.toggle('active', t.dataset.nahj === type));
  renderNahj(type);
}

function renderNahj(type) {
  const list = document.getElementById('nahj-list');
  if (!list || !window.NahjData) return;
  const items = NahjData[type] || [];
  list.innerHTML = '';
  items.forEach(item => {
    const div = document.createElement('div');
    div.className = 'nahj-card';
    const label = type === 'sermons' ? 'Sermon' : type === 'letters' ? 'Letter' : 'Saying';
    div.innerHTML = `
      <div class="nahj-header">
        <div>
          <div class="nahj-label">${label} ${item.id}</div>
          <div style="font-size:13px;color:var(--text-secondary);margin-top:2px;">${item.title}</div>
        </div>
        <div class="nahj-num">${item.titleAr}</div>
      </div>
      <div class="nahj-arabic">${item.arabic}</div>
      <div class="nahj-urdu">${item.urdu}</div>
      <div class="nahj-english">${item.english}</div>
    `;
    list.appendChild(div);
  });
}

window.switchNahjTab = switchNahjTab;
initNahj();

// ═══════════════════════════════════════
//  PRAYER TIMES MODULE
// ═══════════════════════════════════════
let prayerInitialized = false;
let countdownInterval = null;

function initPrayer() {
  if (prayerInitialized) return;
  const saved = JSON.parse(localStorage.getItem('userLocation') || 'null');
  if (saved) {
    renderPrayerTimes(saved.lat, saved.lng, saved.city);
  } else {
    document.getElementById('prayer-loading')?.style.setProperty('display', 'flex');
  }
}

function requestLocation() {
  const btn = document.getElementById('location-btn');
  if (btn) btn.textContent = '📍 Locating...';
  navigator.geolocation?.getCurrentPosition(
    pos => {
      const { latitude: lat, longitude: lng } = pos.coords;
      reverseGeocode(lat, lng).then(city => {
        localStorage.setItem('userLocation', JSON.stringify({ lat, lng, city }));
        renderPrayerTimes(lat, lng, city);
      });
    },
    () => {
      showToast('❌ Location access denied');
      // Default to Karachi
      renderPrayerTimes(24.8607, 67.0011, 'Karachi');
    },
    { timeout: 8000 }
  );
}

async function reverseGeocode(lat, lng) {
  try {
    const r = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`);
    const d = await r.json();
    return d.address?.city || d.address?.town || d.address?.county || 'Your City';
  } catch {
    return 'Your City';
  }
}

function renderPrayerTimes(lat, lng, city) {
  prayerInitialized = true;
  document.getElementById('prayer-loading')?.style.setProperty('display', 'none');

  const date = new Date();
  const times = PrayerCalc.compute(lat, lng, date, 'Karachi');
  const { current, next } = getCurrentAndNextPrayer(times);
  const nextInfo = PRAYER_NAMES[next];

  // Hero
  document.getElementById('prayer-city').textContent = city;
  document.getElementById('prayer-hijri').textContent = toHijri(date);
  document.getElementById('prayer-en-date').textContent = date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  document.getElementById('next-prayer-name').textContent = nextInfo.ar;
  document.getElementById('next-prayer-time').textContent = times[next];

  // Countdown
  if (countdownInterval) clearInterval(countdownInterval);
  const updateCD = () => document.getElementById('prayer-countdown').textContent = `${getCountdown(times[next])} remaining`;
  updateCD();
  countdownInterval = setInterval(updateCD, 60000);

  // Prayer rows
  const list = document.getElementById('prayer-times-list');
  if (!list) return;
  list.innerHTML = '';
  Object.entries(times).forEach(([key, time]) => {
    const info = PRAYER_NAMES[key];
    if (!info) return;
    const div = document.createElement('div');
    div.className = `prayer-row${key === next ? ' current' : ''}`;
    div.innerHTML = `
      <div class="prayer-icon">${info.icon}</div>
      <div class="prayer-info">
        <div class="prayer-name-en">${info.en}</div>
        <div class="prayer-name-ar">${info.ar}</div>
      </div>
      <div class="prayer-time-display">${time}</div>
    `;
    list.appendChild(div);
  });
}

window.requestLocation = requestLocation;

// ═══════════════════════════════════════
//  QIBLA MODULE
// ═══════════════════════════════════════
let qiblaInitialized = false;
let compass = null;

function initQibla() {
  if (qiblaInitialized) return;
  const saved = JSON.parse(localStorage.getItem('userLocation') || 'null');
  if (saved) {
    setupQibla(saved.lat, saved.lng);
  }
}

async function requestQiblaLocation() {
  navigator.geolocation?.getCurrentPosition(
    pos => {
      const { latitude: lat, longitude: lng } = pos.coords;
      localStorage.setItem('userLocation', JSON.stringify({ lat, lng, city: 'Your Location' }));
      setupQibla(lat, lng);
    },
    () => setupQibla(24.8607, 67.0011) // Default Karachi
  );
}

function setupQibla(lat, lng) {
  qiblaInitialized = true;
  const angle = calculateQibla(lat, lng);
  const dist = getDistanceToMakkah(lat, lng);

  document.getElementById('qibla-degree').innerHTML = `${angle}<span>°</span>`;
  document.getElementById('qibla-distance').textContent = `📍 ${dist.toLocaleString()} km to Makkah`;
  document.getElementById('qibla-from-north').textContent = `${angle}° from North`;
  document.getElementById('qibla-loading').style.display = 'none';
  document.getElementById('qibla-main').style.display = '';

  // Compass
  compass = new QiblaCompass((needleRot, heading) => {
    const needle = document.getElementById('compass-needle');
    if (needle) needle.style.transform = `translate(-50%, -100%) rotate(${needleRot}deg)`;
  });
  compass.setQiblaAngle(angle);
  compass.start();
}

async function calibrateCompass() {
  if (compass) {
    const granted = await compass.requestPermission();
    showToast(granted ? '✅ Compass active' : '⚠️ Compass not available');
  }
}

window.requestQiblaLocation = requestQiblaLocation;
window.calibrateCompass = calibrateCompass;

// ═══════════════════════════════════════
//  HADITH MODULE
// ═══════════════════════════════════════
let hadithInitialized = false;

function initHadith() {
  if (hadithInitialized) return;
  hadithInitialized = true;
  const h = HadithData.getDailyHadith();
  renderHadith(h);
  document.getElementById('hadith-date').textContent = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
}

function renderHadith(h) {
  document.getElementById('hadith-arabic').textContent = h.arabic;
  document.getElementById('hadith-urdu').textContent = h.urdu;
  document.getElementById('hadith-english').textContent = h.english;
  document.getElementById('hadith-source').textContent = `${h.source} | ${h.reference}`;
}

function nextHadith() {
  renderHadith(HadithData.getRandomHadith());
  showToast('🔄 New hadith loaded');
}

function shareHadith() {
  const arabic = document.getElementById('hadith-arabic')?.textContent;
  const english = document.getElementById('hadith-english')?.textContent;
  const source = document.getElementById('hadith-source')?.textContent;
  const text = `${arabic}\n\n${english}\n\n— ${source}\n\nIslamic Insights App`;
  if (navigator.share) {
    navigator.share({ title: 'Daily Hadith', text }).catch(() => {});
  } else {
    navigator.clipboard?.writeText(text).then(() => showToast('📋 Copied!'));
  }
}

function copyHadith() {
  const arabic = document.getElementById('hadith-arabic')?.textContent;
  const english = document.getElementById('hadith-english')?.textContent;
  navigator.clipboard?.writeText(`${arabic}\n${english}`).then(() => showToast('📋 Hadith copied!'));
}

window.nextHadith = nextHadith;
window.shareHadith = shareHadith;
window.copyHadith = copyHadith;

// ═══════════════════════════════════════
//  DONATIONS MODULE
// ═══════════════════════════════════════
let selectedAmount = 500;

function initDonate() {
  selectAmount(500);
}

function selectAmount(amt) {
  selectedAmount = amt;
  document.querySelectorAll('.amount-btn').forEach(b => {
    b.classList.toggle('selected', Number(b.dataset.amount) === amt);
  });
  document.getElementById('custom-amount-display').textContent = `PKR ${amt.toLocaleString()}`;
}

function setCustomAmount() {
  const val = parseInt(document.getElementById('custom-amt').value);
  if (val > 0) selectAmount(val);
}

function donatePKR() {
  showToast('🔗 Redirecting to payment...');
  setTimeout(() => {
    window.open(`https://easypaisa.com.pk/payment?amount=${selectedAmount}`, '_blank');
  }, 500);
}

function donatePayPal() {
  window.open(`https://paypal.me/IslamicInsights/${selectedAmount}USD`, '_blank');
}

window.selectAmount = selectAmount;
window.setCustomAmount = setCustomAmount;
window.donatePKR = donatePKR;
window.donatePayPal = donatePayPal;
