// js/qibla.js — Qibla Direction Calculator

const KAABA = { lat: 21.4225, lng: 39.8262 }; // Makkah coordinates

function calculateQibla(lat, lng) {
  const φ1 = lat * Math.PI / 180;
  const φ2 = KAABA.lat * Math.PI / 180;
  const Δλ = (KAABA.lng - lng) * Math.PI / 180;

  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  const θ = Math.atan2(y, x);
  const bearing = (θ * 180 / Math.PI + 360) % 360;

  return Math.round(bearing);
}

function getDistanceToMakkah(lat, lng) {
  const R = 6371; // Earth radius km
  const φ1 = lat * Math.PI / 180;
  const φ2 = KAABA.lat * Math.PI / 180;
  const Δφ = (KAABA.lat - lat) * Math.PI / 180;
  const Δλ = (KAABA.lng - lng) * Math.PI / 180;
  const a = Math.sin(Δφ/2)**2 + Math.cos(φ1)*Math.cos(φ2)*Math.sin(Δλ/2)**2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

// Compass/DeviceOrientation integration
class QiblaCompass {
  constructor(onUpdate) {
    this.onUpdate = onUpdate;
    this.qiblaAngle = 0;
    this.compassHeading = 0;
    this.isListening = false;
    this.permissionGranted = false;
  }

  setQiblaAngle(angle) {
    this.qiblaAngle = angle;
    this.update();
  }

  async requestPermission() {
    if (typeof DeviceOrientationEvent !== 'undefined' &&
        typeof DeviceOrientationEvent.requestPermission === 'function') {
      try {
        const permission = await DeviceOrientationEvent.requestPermission();
        this.permissionGranted = permission === 'granted';
      } catch(e) {
        this.permissionGranted = false;
      }
    } else {
      this.permissionGranted = true;
    }
    return this.permissionGranted;
  }

  start() {
    if (this.isListening) return;
    window.addEventListener('deviceorientationabsolute', this.handleOrientation.bind(this), true);
    window.addEventListener('deviceorientation', this.handleOrientation.bind(this), true);
    this.isListening = true;
  }

  stop() {
    window.removeEventListener('deviceorientationabsolute', this.handleOrientation.bind(this), true);
    window.removeEventListener('deviceorientation', this.handleOrientation.bind(this), true);
    this.isListening = false;
  }

  handleOrientation(e) {
    let heading = 0;
    if (e.webkitCompassHeading !== undefined) {
      heading = e.webkitCompassHeading; // iOS
    } else if (e.absolute && e.alpha !== null) {
      heading = 360 - e.alpha; // Android
    } else if (e.alpha !== null) {
      heading = 360 - e.alpha;
    }
    this.compassHeading = heading;
    this.update();
  }

  update() {
    // Needle rotation: qibla direction relative to current heading
    const needleRotation = (this.qiblaAngle - this.compassHeading + 360) % 360;
    this.onUpdate(needleRotation, this.compassHeading);
  }
}

window.calculateQibla = calculateQibla;
window.getDistanceToMakkah = getDistanceToMakkah;
window.QiblaCompass = QiblaCompass;
