// js/prayer.js — Prayer Times using Adhan.js algorithm

// Prayer calculation based on astronomical formulas (no external dependency)
const PrayerCalc = {
  // Calculation methods
  METHODS: {
    MWL:     { fajr: 18, isha: 17 },  // Muslim World League
    ISNA:    { fajr: 15, isha: 15 },  // Islamic Society of North America
    Egypt:   { fajr: 19.5, isha: 17.5 },
    Makkah:  { fajr: 18.5, isha: '90 min' },
    Karachi: { fajr: 18, isha: 18 },  // University of Islamic Sciences, Karachi
    Tehran:  { fajr: 17.7, isha: 14 },
    Jafari:  { fajr: 16, isha: 14 },  // Shia Ithna Ashari
  },

  // Convert degrees to radians
  toRad: d => d * Math.PI / 180,
  // Convert radians to degrees
  toDeg: r => r * 180 / Math.PI,

  // Sun position
  sunPosition(jd) {
    const D = jd - 2451545.0;
    const g = (357.529 + 0.98560028 * D) % 360;
    const q = (280.459 + 0.98564736 * D) % 360;
    const L = (q + 1.915 * Math.sin(this.toRad(g)) + 0.020 * Math.sin(this.toRad(2 * g))) % 360;
    const e = 23.439 - 0.00000036 * D;
    const RA = this.toDeg(Math.atan2(Math.cos(this.toRad(e)) * Math.sin(this.toRad(L)), Math.cos(this.toRad(L)))) / 15;
    const eqt = q / 15 - ((RA + 24) % 24);
    const decl = this.toDeg(Math.asin(Math.sin(this.toRad(e)) * Math.sin(this.toRad(L))));
    return { decl, eqt };
  },

  // Julian Day Number
  julianDay(date) {
    const y = date.getFullYear(), m = date.getMonth() + 1, d = date.getDate();
    if (m <= 2) return Math.floor(365.25 * (y - 1)) + Math.floor(30.6001 * (m + 13)) + d + 1720994.5;
    return Math.floor(365.25 * y) + Math.floor(30.6001 * (m + 1)) + d + 1720994.5;
  },

  // Prayer angle to time
  prayerTime(angle, lat, decl, midday, dir = 1) {
    const cosT = (Math.cos(this.toRad(angle)) - Math.sin(this.toRad(lat)) * Math.sin(this.toRad(decl))) /
                 (Math.cos(this.toRad(lat)) * Math.cos(this.toRad(decl)));
    if (Math.abs(cosT) > 1) return NaN;
    return midday + dir * this.toDeg(Math.acos(cosT)) / 15;
  },

  // Compute all prayer times
  compute(lat, lng, date, method = 'Karachi', timezone = null) {
    const jd = this.julianDay(date);
    const { decl, eqt } = this.sunPosition(jd + 0.5 - lng / 360);
    const midday = 12 - eqt - lng / 15;

    const m = this.METHODS[method] || this.METHODS.Karachi;
    const fajrAngle = m.fajr;
    const ishaAngle = typeof m.isha === 'number' ? m.isha : 18;

    const fajr   = this.prayerTime(fajrAngle,   lat, decl, midday, -1);
    const sunrise = this.prayerTime(0.833,       lat, decl, midday, -1);
    const dhuhr  = midday + 0.5 / 60;
    const asr    = this.asrTime(lat, decl, midday, 1); // Shafi
    const maghrib = this.prayerTime(0.833,       lat, decl, midday, 1);
    const isha   = typeof m.isha === 'string'
      ? maghrib + 1.5
      : this.prayerTime(ishaAngle, lat, decl, midday, 1);

    const tz = timezone !== null ? timezone : -date.getTimezoneOffset() / 60;

    return {
      fajr:    this.floatToTime(fajr + tz),
      sunrise: this.floatToTime(sunrise + tz),
      dhuhr:   this.floatToTime(dhuhr + tz),
      asr:     this.floatToTime(asr + tz),
      maghrib: this.floatToTime(maghrib + tz),
      isha:    this.floatToTime(isha + tz),
    };
  },

  asrTime(lat, decl, midday, shadow) {
    const angle = -this.toDeg(Math.atan(1 / (shadow + Math.tan(this.toRad(Math.abs(lat - decl))))));
    return this.prayerTime(angle, lat, decl, midday, 1);
  },

  floatToTime(t) {
    t = ((t % 24) + 24) % 24;
    const h = Math.floor(t);
    const m = Math.round((t - h) * 60);
    const hh = m >= 60 ? h + 1 : h;
    const mm = m >= 60 ? 0 : m;
    return `${String(hh % 24).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
  }
};

// Islamic Date Converter
function toHijri(date) {
  const y = date.getFullYear(), m = date.getMonth() + 1, d = date.getDate();
  let jd = Math.floor((14 + m * 30 - 30 * Math.floor((m + 9) / 12)) / 30 + 1) +
           Math.floor(365.25 * (y + 4716)) +
           Math.floor(30.6001 * (m + 1)) + d - 1524;

  jd = jd - Math.floor(jd / 36524.25) + Math.floor(jd / 146097) + 38;
  const al = jd + 1402;
  const b = Math.floor((al - 1) / 1461);
  const c = al - 1461 * b;
  const d4 = Math.floor((c - 1) / 365) - Math.floor(c / 1461);
  const e = c - 365 * d4 - Math.floor(d4 / 4);
  const f = Math.floor(30 * (e - 1) / 917 + 2);
  const dd = e - Math.floor(917 * f / 30) - 1;
  const mm = f <= 10 ? f + 2 : f - 10;
  const yy = b * 4 + d4 + Math.floor((f - 2) / 12) - 4716;

  const months = ['محرم','صفر','ربیع الاول','ربیع الثانی','جمادی الاول','جمادی الثانی','رجب','شعبان','رمضان','شوال','ذوالقعدہ','ذوالحجہ'];
  return `${dd} ${months[mm - 1]} ${yy}ھ`;
}

// Prayer names
const PRAYER_NAMES = {
  fajr:    { en: 'Fajr',    ar: 'الفجر',   icon: '🌙', urdu: 'فجر' },
  sunrise: { en: 'Sunrise', ar: 'الشروق',  icon: '🌅', urdu: 'طلوع' },
  dhuhr:   { en: 'Dhuhr',   ar: 'الظهر',   icon: '☀️', urdu: 'ظہر' },
  asr:     { en: 'Asr',     ar: 'العصر',   icon: '🌤️', urdu: 'عصر' },
  maghrib: { en: 'Maghrib', ar: 'المغرب',  icon: '🌆', urdu: 'مغرب' },
  isha:    { en: 'Isha',    ar: 'العشاء',  icon: '🌃', urdu: 'عشاء' },
};

// Get current and next prayer
function getCurrentAndNextPrayer(times) {
  const now = new Date();
  const nowMins = now.getHours() * 60 + now.getMinutes();
  const keys = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];

  let current = 'isha', next = 'fajr';
  for (let i = 0; i < keys.length; i++) {
    const [h, m] = times[keys[i]].split(':').map(Number);
    const mins = h * 60 + m;
    if (nowMins < mins) {
      next = keys[i];
      current = i > 0 ? keys[i - 1] : 'isha';
      break;
    }
  }
  return { current, next };
}

// Countdown to next prayer
function getCountdown(nextTime) {
  const now = new Date();
  const [h, m] = nextTime.split(':').map(Number);
  const target = new Date(now);
  target.setHours(h, m, 0, 0);
  if (target < now) target.setDate(target.getDate() + 1);
  const diff = target - now;
  const hrs = Math.floor(diff / 3600000);
  const mins = Math.floor((diff % 3600000) / 60000);
  return `${hrs}h ${mins}m`;
}

window.PrayerCalc = PrayerCalc;
window.toHijri = toHijri;
window.PRAYER_NAMES = PRAYER_NAMES;
window.getCurrentAndNextPrayer = getCurrentAndNextPrayer;
window.getCountdown = getCountdown;
