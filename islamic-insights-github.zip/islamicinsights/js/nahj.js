// js/nahj.js — Nahj al-Balagha Complete Data

const NAHJ_DATA = {
  sermons: [
    {
      id: 1,
      title: "The First Sermon",
      titleAr: "الخطبة الأولى",
      arabic: "الحَمدُ لِلهِ الَّذِي لا يَبلُغُ مِدحَتَهُ القَائِلُونَ، وَلا يُحصِي نَعمَاءَهُ العَادُّونَ، وَلا يُؤَدِّي حَقَّهُ المُجتَهِدُونَ الَّذِي لا يُدرِكُهُ بُعدُ الهِمَمِ، وَلا يَنَالُهُ غَوصُ الفِطَنِ.",
      urdu: "ہر تعریف اس اللہ کے لیے جسے بولنے والے مکمل طور پر بیان نہیں کر سکتے، جن کی نعمتوں کو گننے والے شمار نہیں کر سکتے اور جن کا حق ادا کرنے والے پورا حق نہیں ادا کر سکتے۔ اسے عالی ہمت بھی نہیں پا سکتے اور گہری سمجھ والے بھی اس تک نہیں پہنچ سکتے۔",
      english: "Praise be to Allah Whose worth cannot be described by speakers, Whose bounties cannot be counted by calculators and Whose claim (to obedience) cannot be satisfied by those who attempt to do so. Whom the height of intellectual courage cannot appreciate, and the divings of understanding cannot reach."
    },
    {
      id: 2,
      title: "On Creation of the World",
      titleAr: "خطبة في خلق العالم",
      arabic: "أَنشَأَ الخَلقَ إِنشَاءً، وَابتَدَأَهُ ابتِدَاءً، بِلا رَوِيَّةٍ أَجَالَهَا، وَلا تَجرِبَةٍ استَفَادَهَا، وَلا حَرَكَةٍ أَحدَثَهَا، وَلا هِمَامَةِ نَفسٍ اضطَرَبَ فِيهَا.",
      urdu: "اس نے مخلوق کو پیدا کیا اور آغاز کیا، بغیر کسی سوچ بچار کے جو وہ کرتا، بغیر کسی تجربے سے جو اس نے حاصل کیا ہو، بغیر کسی حرکت کے جو اس نے اختیار کی ہو، اور بغیر کسی ہمت کی بے چینی کے جس میں وہ مضطرب ہوا ہو۔",
      english: "He created creation without any prevailing need, nor for any benefit He expected. He neither needed population to profit from them, nor was He afraid of emptiness and loneliness."
    },
    {
      id: 3,
      title: "The Shiqshiqiyya Sermon",
      titleAr: "خطبة الشقشقية",
      arabic: "أَمَا وَاللَّهِ لَقَدْ تَقَمَّصَهَا فُلانٌ، وَإِنَّهُ لَيَعْلَمُ أَنَّ مَحَلِّي مِنْهَا مَحَلُّ الْقُطْبِ مِنَ الرَّحَى. يَنْحَدِرُ عَنِّي السَّيْلُ، وَلَا يَرْقَى إِلَيَّ الطَّيْرُ.",
      urdu: "یاد رہے، اللہ کی قسم! فلاں نے اسے (خلافت) کو پہن لیا حالانکہ وہ جانتا تھا کہ اس میں میرا مقام ایسا ہے جیسے چکی میں محور کا۔ میرے یہاں سے سیلاب بہتا ہے اور اونچی پرواز کرنے والا پرندہ میرے مقام تک نہیں پہنچ سکتا۔",
      english: "By Allah, he put on its garment while he certainly knew that my position in relation to it was the same as the position of the axle in relation to the hand-mill. The flood water flows down from me and the bird cannot fly up to me."
    },
    {
      id: 4,
      title: "On Piety and Taqwa",
      titleAr: "في التقوى والزهد",
      arabic: "فَاتَّقُوا اللَّهَ عِبَادَ اللَّهِ وَبَادِرُوا آجَالَكُم بِأَعمَالِكُم، وَابتَاعُوا مَا يَبقَى لَكُم بِمَا يَزُولُ عَنكُم.",
      urdu: "اے اللہ کے بندو! اللہ سے ڈرو اور اپنے اعمال سے اپنی موت سے پہلے آگے بڑھو، اور جو تم سے زائل ہو جانے والا ہے اس سے وہ خریدو جو تمہارے لیے باقی رہے گا۔",
      english: "So fear Allah, O servants of Allah, and hasten towards your (good) deeds before your deaths, and buy (for the next life) with what is perishable (worldly things) what will remain for you (eternal reward)."
    },
    {
      id: 5,
      title: "On the Characteristics of the Pious",
      titleAr: "في صفات المتقين",
      arabic: "التَّقوى سَيِّدُ الأَعمَالِ. مَن أَخَذَ بِالتَّقوى أَخَذَ بِحَبلٍ وَثِيقٍ وَبِعُروَةِ الإِسلامِ المُثلَى.",
      urdu: "تقویٰ اعمال کا سردار ہے۔ جس نے تقویٰ اختیار کیا اس نے ایک مضبوط رسی کو تھام لیا اور اسلام کی مضبوط ترین کڑی کو پکڑ لیا۔",
      english: "Piety is the chief of all actions. Whoever takes to piety, he has taken hold of a strong rope and the most reliable handle of Islam."
    }
  ],
  letters: [
    {
      id: 1,
      title: "To Malik al-Ashtar",
      titleAr: "إلى مالك الأشتر",
      arabic: "هَذَا مَا أَمَرَ بِهِ عَبدُ اللهِ عَلِيٌّ أَمِيرُ المُؤمِنِينَ مَالِكَ بنَ الحَارِثِ الأَشتَرَ فِي عَهدِهِ إِلَيهِ، حِينَ وَلَّاهُ مِصرَ جِبَايَتَهَا، وَجِهَادَ عَدُوِّهَا.",
      urdu: "یہ وہ حکم ہے جو اللہ کے بندے علی امیرالمومنین نے مالک ابن حارث اشتر کو اپنے اس عہد نامے میں دیا جب انہیں مصر کی گورنری پر مقرر کیا۔",
      english: "This is what Allah's servant Ali, the Commander of the Faithful, has directed Malik ibn al-Harith al-Ashtar in his covenant to him, when he appointed him as Governor of Egypt."
    },
    {
      id: 2,
      title: "To His Brother Aqeel",
      titleAr: "إلى أخيه عقيل",
      arabic: "أَمَّا بَعدُ، فَإِنِّي كُنتُ أُشرِكُكَ فِي أَمَانَتِي، وَأَجعَلُكَ شِعَارِي وَبِطَانَتِي، وَلَم يَكُن مِن أَهلِي رَجُلٌ أَوثَقَ مِنكَ فِي نَفسِي لِمُوَاسَاتِي.",
      urdu: "اما بعد، میں تمہیں اپنی امانت میں شریک کرتا تھا اور تمہیں اپنا قریبی رازدان بناتا تھا۔ میرے اہل خانہ میں کوئی مرد تم سے زیادہ میری ہمدردی کے لیے قابل اعتماد نہیں تھا۔",
      english: "Now then, I used to make you a partner in my trust and make you my intimate companion, and there was no man among my family whom I trusted more for sympathizing with me."
    },
    {
      id: 3,
      title: "To Muawiyah",
      titleAr: "إلى معاوية",
      arabic: "إِنَّهُ بَايَعَنِي القَومُ الَّذِينَ بَايَعُوا أَبَا بَكرٍ وَعُمَرَ وَعُثمَانَ عَلَى مَا بَايَعُوهُم عَلَيهِ، فَلَم يَكُن لِلشَّاهِدِ أَن يَختَارَ وَلَا لِلغَائِبِ أَن يَرُدَّ.",
      urdu: "وہی لوگوں نے مجھ سے بیعت کی جنہوں نے ابوبکر، عمر اور عثمان سے اسی بنیاد پر بیعت کی تھی۔ نہ حاضر کو اختیار تھا کہ انکار کرے اور نہ غائب کو حق تھا کہ رد کرے۔",
      english: "The same people who swore allegiance to Abu Bakr, Umar, and Uthman have sworn allegiance to me on the same basis. So no one present has the right to go against it, nor has anyone absent the right to reject it."
    }
  ],
  aphorisms: [
    {
      id: 1,
      titleAr: "حكمة ١",
      arabic: "قِيمَةُ كُلِّ امرِئٍ مَا يُحسِنُهُ.",
      urdu: "ہر شخص کی قدر اس بات سے ہے جو وہ اچھی طرح جانتا ہو۔",
      english: "The value of every person is in what he excels."
    },
    {
      id: 2,
      titleAr: "حكمة ٢",
      arabic: "لَا تَستَحِ مِن إِعطَاءِ القَلِيلِ، فَإِنَّ الحِرمَانَ أَقَلُّ مِنهُ.",
      urdu: "تھوڑا دینے سے شرم نہ کرو، کیونکہ محروم رکھنا اس سے بھی کم ہے۔",
      english: "Do not feel ashamed for giving a little, because withholding is still less than that."
    },
    {
      id: 3,
      titleAr: "حكمة ٣",
      arabic: "مَن نَصَبَ نَفسَهُ لِلنَّاسِ إِمَاماً فَليَبدَأ بِتَعلِيمِ نَفسِهِ قَبلَ تَعلِيمِ غَيرِهِ.",
      urdu: "جو شخص خود کو لوگوں کا رہنما بنائے، اسے دوسروں کو سکھانے سے پہلے خود کو سکھانا چاہیے۔",
      english: "Whoever appoints himself as an Imam of the people must start educating himself before educating others."
    },
    {
      id: 4,
      titleAr: "حكمة ٤",
      arabic: "كُن فِي الفِتنَةِ كَابنِ اللَّبُونِ، لَا ظَهرٌ فَيُركَبَ، وَلَا ضَرعٌ فَيُحلَبَ.",
      urdu: "فتنے میں دو سالہ اونٹنی کے بچے کی طرح رہو جس کی نہ پیٹھ ہے کہ سوار ہوا جائے اور نہ تھن ہے کہ دودھ دوہا جائے۔",
      english: "In times of civil strife, be like a young camel — neither with a back to ride nor with udders to milk (i.e., be neutral and uninvolved)."
    },
    {
      id: 5,
      titleAr: "حكمة ٥",
      arabic: "اِبدَأ قَبلَ أَن تُبدَأَ بِكَ.",
      urdu: "پہل کرو اس سے پہلے کہ تم سے پہل کی جائے۔",
      english: "Begin before you are begun with."
    },
    {
      id: 6,
      titleAr: "حكمة ٦",
      arabic: "الصَّمتُ حُكمٌ وَقَلِيلٌ فَاعِلُهُ.",
      urdu: "خاموشی حکمت ہے لیکن اس پر عمل کرنے والے کم ہیں۔",
      english: "Silence is wisdom, yet few practice it."
    },
    {
      id: 7,
      titleAr: "حكمة ٧",
      arabic: "لَا تَقُولَنَّ مَا لَا تَعلَمُ، بَل لَا تَقُل كُلَّ مَا تَعلَمُ.",
      urdu: "وہ نہ کہو جو تم نہیں جانتے، بلکہ وہ سب بھی نہ کہو جو تم جانتے ہو۔",
      english: "Do not say what you do not know, rather do not say everything you know."
    },
    {
      id: 8,
      titleAr: "حكمة ٨",
      arabic: "إِذَا قَدَرتَ عَلَى عَدُوِّكَ فَاجعَل العَفوَ عَنهُ شُكراً لِلقُدرَةِ عَلَيهِ.",
      urdu: "جب تم اپنے دشمن پر قابو پاؤ تو اس سے درگزر کو اس قابو پانے پر شکرانہ بناؤ۔",
      english: "When you have power over your enemy, make forgiveness your gratitude for that power."
    }
  ]
};

window.NahjData = NAHJ_DATA;
